﻿using System.ComponentModel.DataAnnotations;

namespace _2024_2C_SushiPOP_G5.Models
{
    public class LoginViewModel
    {
        [Required(ErrorMessage = ErrorViewModel.CampoRequerido)]
        public string Email { get; set; }

        [Required(ErrorMessage = ErrorViewModel.CampoRequerido)]
        public string Password { get; set; }
    }
}
