﻿using Microsoft.AspNetCore.Mvc;

namespace _2024_2C_SushiPOP_G5.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
